package com.dam.cst.juego;

import com.dam.frameWorkGame.PixMap;
import com.dam.frameWorkGame.Sprite;

/**
 * Created by PROFDAM on 24/11/2017.
 */

public class Boton extends Sprite {

    private static PixMap pmAgujeroRojo=new PixMap("boton.png");
    //private static final int  BAJANDO=0;
    //private static final int  SUBIENDO=1;
    //private int estado;
    private int tCreacion;
    private static int STEP=8;
    private boolean barrera;

    public Boton(int x,int y) {
        super(pmAgujeroRojo);
        barrera=true;
        this.setX(x);
        this.setY(y);
        crear();
    }//fin constructor

    @Override
    public void actualizar(int deltaTime) {
        /*if (estado==BAJANDO){
            caer();
        }else{
            subir();
        }*/
    }

    /*public void subir(){

        this.setY(this.getY()-STEP);

        if (this.getY()<0){
            estado=BAJANDO;
            iniciar();
        }
    }
    public void caer(){

        this.setY(this.getY()+STEP);

        if (this.getY()>juego.getAlto()-this.getAlto()){
            estado=SUBIENDO;
            iniciar();
        }
    }*/
    public void iniciar(){
        tCreacion=this.generandoTiempo();
    }


    public int generandoTiempo(){
        return (int)(Math.random()*50+10);
    }

    @Override
    public void chocar(Sprite sp) {
        if(sp instanceof Bola) {
            barrera = false;
        }
    }
    public void crear(){
        setVisible(true);
        setHabilitado(true);
        //estado=BAJANDO;
        iniciar();
    }
    public void destruir(){
        setVisible(false);
        setHabilitado(false);
    }
    public boolean isBarrera() {
        return barrera;
    }

    public void setBarrera(boolean barrera) {
        this.barrera = barrera;
    }
}
