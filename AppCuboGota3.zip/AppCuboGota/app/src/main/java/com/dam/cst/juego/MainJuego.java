/**
 * DESARROLLO DE APLICACIONES MULTIPLATAFORMA
 * MODULO: PROGRAMACION MULTIMEDIA Y DISPOSITIVOS MOVILES
 * CENTRO: COLEGIO STMA TRINIDAD
 * CURSO: 2016-2017
 **/
package com.dam.cst.juego;

import com.dam.frameWorkGame.Game;
import com.dam.frameWorkGame.SpriteTexto;

public class MainJuego extends Game {
    private Agujero agujeroIzq;
    private Agujero agujeroCen;
    private Agujero agujeroDer;
    private AgujeroRojo agujeroRojo;
    private AgujeroVerde agujeroVerde;
    private ParedMovil paredmovil1;
    private ParedMovil paredmovil2;
    private Boton botonDer;
    private Boton botonCen;
    private Boton botonIzq;
    private Bola bola;
    private Barrera barreraDer;
    private Barrera barreraArr;
    private Barrera barreraAba;
    private Pared[] pared;
    private int[] xpared={0,200,200,200,200,200,200,200,200,200,200,200, 800,800,800,800,800,800,800,800,800,800,800,800,800};
    private int[] ypared={50,0,50,100,150,300,350,400,450,600,650,700 ,0,50,100,150,200,250,300,350,400,450,600,650,700};
    private SpriteTexto contadorGotas;
    private SpriteTexto titulo;
    @Override
    public void iniciarJuego() {


        agujeroIzq=new Agujero(100,22);
        agujeroCen=new Agujero(400,14);
        agujeroDer=new Agujero(this.getAncho()-150,8);
        agujeroRojo=new AgujeroRojo();
        agujeroVerde=new AgujeroVerde();
        paredmovil1 = new ParedMovil(600,15);
        paredmovil2 = new ParedMovil(1000,7);
        botonCen=new Boton(500,0);
        botonIzq=new Boton(0,650);
        botonDer=new Boton(900,0);
        barreraDer=new Barrera(800,500);
        barreraArr=new Barrera(200,200);
        barreraAba=new Barrera(200,500);
        bola=new Bola(this);
        for(int i=0;i<xpared.length;i++)
        {
            new Pared(xpared[i],ypared[i]);
        }
        contadorGotas=new SpriteTexto("EUREKA");
        contadorGotas.setPosicion(600,200);

        titulo=new SpriteTexto("");
        titulo.setPosicion(50,50);
        this.setTimeFrame(20);

    }

    @Override
    public void actualizar(long deltaTime) {
        contadorGotas.setTexto(""+bola.getContador());
        if(!botonDer.isBarrera()){
            barreraDer.destruir();
        }
        if(!botonCen.isBarrera()){
            barreraArr.destruir();
            barreraAba.destruir();
        }
        if(!botonIzq.isBarrera()){

        }
        if (agujeroVerde.isTocado()) {
            barreraDer.crear();
            barreraArr.crear();
            barreraAba.crear();
            agujeroVerde.setTocado(false);
            botonCen.setBarrera(true);
            botonDer.setBarrera(true);
            botonIzq.setBarrera(true);
        }

      /*  GestorDedo dedo=getGestorDedo();
        if (dedo.isTocada()){
            bola.doAccion(dedo.getTouchEvento().x,dedo.getTouchEvento().y);
        }*/

    }


}
