package com.dam.cst.juego;

import com.dam.frameWorkGame.PixMap;
import com.dam.frameWorkGame.Sprite;

/**
 * Created by PROFDAM on 24/11/2017.
 */

public class Agujero extends Sprite {

        private static PixMap pmGota=new PixMap("negro.png");
        private static final int  BAJANDO=0;
        private static final int  SUBIENDO=1;
        private int estado;
        private int tCreacion;
        private int STEP;
    public Agujero(int x,int STEP) {
            super(pmGota);
            this.STEP=STEP;
            this.setX(x);
            this.setY((int)(Math.random()*(juego.getAlto()-this.getAlto())));
            crear();
        }//fin constructor

    @Override
    public void actualizar(int deltaTime) {
        if (estado==BAJANDO){
            caer();
        }else{
            subir();
        }
    }

    public void subir(){

        this.setY(this.getY()-STEP);

        if (this.getY()<0){
            estado=BAJANDO;
            iniciar();
        }
    }
    public void caer(){

        this.setY(this.getY()+STEP);

        if (this.getY()>juego.getAlto()-this.getAlto()){
            estado=SUBIENDO;
            iniciar();
        }
    }
    public void iniciar(){
        tCreacion=this.generandoTiempo();
    }


    public int generandoTiempo(){
        return (int)(Math.random()*50+10);
    }

    @Override
    public void chocar(Sprite sp) {
        //destruir();
    }
    public void crear(){
        setVisible(true);
        setHabilitado(true);
        estado=BAJANDO;
        iniciar();
    }
    public void destruir(){
        setVisible(false);
        setHabilitado(false);
    }
}