/**
 * DESARROLLO DE APLICACIONES MULTIPLATAFORMA
 * MODULO: PROGRAMACION MULTIMEDIA Y DISPOSITIVOS MOVILES
 * CENTRO: COLEGIO STMA TRINIDAD
 * CURSO: 2016-2017
 **/
package com.dam.cst.juego;

import com.dam.frameWorkGame.Game;
import com.dam.frameWorkGame.SpriteTexto;

public class MainJuego extends Game {
    private Agujero agujeroIzq;
    private Agujero agujeroDer;
    private Bola bola;
    private Pared pared1;
    private Pared pared2;
    private Pared pared3;
    private Pared pared4;
    private SpriteTexto contadorGotas;
    private SpriteTexto titulo;
    @Override
    public void iniciarJuego() {

        bola=new Bola(this);
        agujeroIzq=new Agujero(100);
        agujeroDer=new Agujero(this.getAncho()-150);
        pared1=new Pared(200,0);
        pared2=new Pared(200,50);
        pared3=new Pared(200,100);
        pared4=new Pared(200,150);

        contadorGotas=new SpriteTexto("EUREKA");
        contadorGotas.setPosicion(600,200);

        titulo=new SpriteTexto("METE PELOTA");
        titulo.setPosicion(50,50);
        this.setTimeFrame(20);

    }

    @Override
    public void actualizar(long deltaTime) {
        contadorGotas.setTexto(""+bola.getContador());
      /*  GestorDedo dedo=getGestorDedo();
        if (dedo.isTocada()){
            bola.doAccion(dedo.getTouchEvento().x,dedo.getTouchEvento().y);
        }*/

    }


}
