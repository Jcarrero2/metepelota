package com.dam.cst.juego;

import com.dam.frameWorkGame.PixMap;
import com.dam.frameWorkGame.Sprite;

/**
 * Created by Jose on 20/12/2017.
 */

public class Pared extends Sprite {

    private static PixMap pmGota=new PixMap("pared.png");
    private static final int  BAJANDO=0;
    private static final int  SUBIENDO=1;
    private int estado;
    private int tCreacion;
    private static int STEP=8;
    public Pared(int x,int y) {
        super(pmGota);
        this.setX(x);
        this.setY(y);

    }//fin constructor

    @Override
    public void actualizar(int deltaTime) {

    }


    @Override
    public void chocar(Sprite sp) {
        //destruir();
    }

}