package com.dam.frameWorkGame;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.MotionEvent;
import android.view.View;

/**
 * Created by Jose on 20/12/2017.
 */

public class GestorAcelerometro implements SensorEventListener {
    private EventoMover eventoMover;
    private Game game;
    private SensorManager mSensor;
    private Sensor acelerometro;

    public static class EventoMover {
        public int x, y;
    }
    public GestorAcelerometro(Game game, SensorManager sensorManager, Sensor acelerometro){
        this.mSensor=sensorManager;
        this.acelerometro=acelerometro;
        mSensor.registerListener(this, acelerometro,3);
        this.game=game;
        eventoMover=new EventoMover();
    }

    @Override
    public void onSensorChanged(SensorEvent se) {
        synchronized (this){
            if(se.sensor.getType()== Sensor.TYPE_ACCELEROMETER) {
                eventoMover.x=(int)se.values[1];
                eventoMover.y=(int)se.values[0];
                System.out.println("x"+eventoMover.x+" y"+eventoMover.y);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }


    public EventoMover getEventoAcelerometro(){
        return eventoMover;
    }
}
