package com.dam.frameWorkGame;

/**
 * Created by PROFDAM on 24/11/2017.
 */

public interface Controlable {
    //public void doAccion(GestorDedo.EventoTocar accion);
    public void doAccion(GestorAcelerometro.EventoMover accion);
}
