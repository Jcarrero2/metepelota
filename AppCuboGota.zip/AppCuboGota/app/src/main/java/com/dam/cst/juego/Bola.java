package com.dam.cst.juego;

import android.content.Context;
import android.os.Vibrator;

import com.dam.frameWorkGame.Controlable;
import com.dam.frameWorkGame.GestorAcelerometro;
import com.dam.frameWorkGame.GestorDedo;
import com.dam.frameWorkGame.PixMap;
import com.dam.frameWorkGame.Sprite;

/**
 * Created by PROFDAM on 24/11/2017.
 */
public class Bola extends Sprite implements Controlable {
    private static PixMap pmCubo=new PixMap("naranja.png");
    private static final int PARADO=0;
    private static final int DERECHA=1;
    private static final int IZQUIERDA=2;
    private int direccion;
    private int contadorGotas;
    private MainJuego game;

    public Bola(MainJuego game) {
        super(pmCubo);
        this.game=game;
        this.setY(juego.getAlto()/2);
        this.setX(juego.getAncho()/2);
        //direccion=PARADO;
    }
    /*public void moverDcha(){
        this.setX(this.getX()+10);
        //   if (this.x+this.ancho>juego.getAncho()){
        //       this.x=juego.getAncho()-this.ancho;
        //   }
        if (this.getX()>juego.getAncho())
            this.setX(-this.getAncho());
        //this.setX(this.getX()+10)
    }
    public void moverIzda(){
        this.setX(this.getX()-10);
        //   if (this.x<0){
        //       this.x=0;
        //   }
        if ((this.getX()+this.getAncho())<0)
            this.setX(juego.getAncho());
    }
    public void parar(){

    }

    /*@Override
    public void doAccion(GestorDedo.EventoTocar accion) {

    }*/

    @Override
    public void doAccion(GestorAcelerometro.EventoMover accion) {
        //if (accion.x>500)   direccion=DERECHA;
        //if (accion.x<300)   direccion=IZQUIERDA;

        this.setY(this.getY()+(3*accion.y));
        this.setX(this.getX()+(3*accion.x));
        System.out.println("rrrrrrrrrrrrrrrrrrrrrrrrrrrrrx"+this.getX()+" y"+this.getY());
        if(this.getY()>juego.getAlto()-this.getAlto()){
            this.setY(juego.getAlto()-this.getAlto());
        }
        if(this.getY()<0){
            this.setY(0);
        }
        if(this.getX()>juego.getAncho()-this.getAncho()){
            this.setX(juego.getAncho()-this.getAncho());
        }
        if(this.getX()<0){
            this.setX(0);
        }
    }

    @Override
    public void actualizar(int deltaTime) {
        /*switch (direccion){
            case DERECHA:
                this.moverDcha();
                break;
            case IZQUIERDA:
                this.moverIzda();
                break;
            case PARADO:
                this.parar();
                break;
        }*/
        juego.verColisiones(this);
    }

    @Override
    public void chocar(Sprite sp) {
        if(sp instanceof Agujero){
            contadorGotas++;
            this.setY(juego.getAlto()/2);
            this.setX(juego.getAncho()/2);
        }
        if(sp instanceof Pared){
            final Vibrator vibrator=(Vibrator)game.getSystemService(Context.VIBRATOR_SERVICE);
            long tiempo=600;
            vibrator.vibrate(tiempo);
            this.setX(this.getX()-3);
            this.setY(this.getY()-3);
        }

    }
    public int getContador(){
        return contadorGotas;
    }

}