package com.dam.cst.juego;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.widget.TextView;
import android.widget.Toast;

import com.dam.frameWorkGame.Controlable;
import com.dam.frameWorkGame.GestorDedo;
import com.dam.frameWorkGame.PixMap;
import com.dam.frameWorkGame.Sprite;

/**
 * Created by WINDOWS on 18/12/2017.
 */
public class Pelota extends Sprite implements Controlable,SensorEventListener {
    private static PixMap pmPelota=new PixMap("naranja.png");
    private static final int PARADO=0;
    private static final int DERECHA=1;
    private static final int IZQUIERDA=2;
    private int direccion;
    private int contadorPelotas;
    private long last_update = 0, last_movement = 0;
    private float prevX = 0, prevY = 0, prevZ = 0;
    private float curX = 0, curY = 0, curZ = 0;


    public Pelota() {

        super(pmPelota);
        this.setY(juego.getAlto()-this.getAlto());
        direccion=PARADO;
    }
    public void moverDcha(){
        this.setX(this.getX()+10);
        //   if (this.x+this.ancho>juego.getAncho()){
        //       this.x=juego.getAncho()-this.ancho;
        //   }
        if (this.getX()>juego.getAncho())
            this.setX(-this.getAncho());
        //this.setX(this.getX()+10)
    }
    public void moverIzda(){
        this.setX(this.getX()-10);
        //   if (this.x<0){
        //       this.x=0;
        //   }
        if ((this.getX()+this.getAncho())<0)
            this.setX(juego.getAncho());
    }
    public void parar(){

    }

    @Override
    public void doAccion(GestorDedo.EventoTocar accion) {
        if (accion.x>500)   direccion=DERECHA;
        if (accion.x<300)   direccion=IZQUIERDA;
    }

    @Override
    public void actualizar(int deltaTime) {
        switch (direccion){
            case DERECHA:
                this.moverDcha();
                break;
            case IZQUIERDA:
                this.moverIzda();
                break;
            case PARADO:
                this.parar();
                break;
        }
        juego.verColisiones(this);
    }

    @Override
    public void chocar(Sprite sp) {
        contadorPelotas++;
    }
    public int getContador(){
        return contadorPelotas;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        synchronized (this) {
            long current_time = event.timestamp;

            curX = event.values[0];
            curY = event.values[1];
            curZ = event.values[2];

            if (prevX == 0 && prevY == 0 && prevZ == 0) {
                last_update = current_time;
                last_movement = current_time;
                prevX = curX;
                prevY = curY;
                prevZ = curZ;
            }

            long time_difference = current_time - last_update;
            if (time_difference > 0) {
                float movement = Math.abs((curX + curY + curZ) - (prevX - prevY - prevZ)) / time_difference;
                int limit = 1500;
                float min_movement = 1E-6f;
                if (movement > min_movement) {
                    if (current_time - last_movement >= limit) {
                        Toast.makeText(getApplicationContext(), "Hay movimiento de " + movement, Toast.LENGTH_SHORT).show();
                    }
                    last_movement = current_time;
                }
                prevX = curX;
                prevY = curY;
                prevZ = curZ;
                last_update = current_time;
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

}