package com.dam.cst.juego;

import com.dam.frameWorkGame.Controlable;
import com.dam.frameWorkGame.GestorDedo;
import com.dam.frameWorkGame.PixMap;
import com.dam.frameWorkGame.Sprite;

/**
 * Created by PROFDAM on 24/11/2017.
 */
public class Agujero extends Sprite  {
    private static PixMap pmAgujero=new PixMap("negro.png");
    private static final int PARADO=0;
    private static final int ARRIBA=1;
    private static final int ABAJO=2;
    private int direccion;
    private int contadorPelotas;


    public Agujero(int dato) {
        super(pmAgujero);
        this.setY(juego.getAlto()-this.getAlto());
        direccion=ARRIBA;
        this.setX(dato);
    }

    public void moverArriba(){
        this.setY(this.getY()-10);

        if (this.getY()<0)
            direccion=ABAJO;
    }
    public void moverAbajo(){
        this.setY(this.getY()+10);

        if ((this.getY())>juego.getAlto()-this.getAlto())
            direccion=ARRIBA;

    }
    public void parar(){

    }

    @Override
    public void actualizar(int deltaTime) {
        switch (direccion){
            case ARRIBA:
                this.moverArriba();
                break;
            case ABAJO:
                this.moverAbajo();
                break;
            case PARADO:
                this.parar();
                break;
        }
        juego.verColisiones(this);
    }

    @Override
    public void chocar(Sprite sp) {
        contadorPelotas++;
    }
    public int getContador(){
        return contadorPelotas;
    }

}