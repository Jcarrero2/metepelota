package com.dam.cst.juego;

import com.dam.frameWorkGame.PixMap;
import com.dam.frameWorkGame.Sprite;

/**
 * Created by PROFDAM on 24/11/2017.
 */

public class Gota extends Sprite {

        private static PixMap pmGota=new PixMap("gota.png");
        private static final int  BAJANDO=0;
        private static final int  ESPERANDO=1;
        private int estado;
        private int tCreacion;
        private static int STEP=8;
    public Gota() {
            super(pmGota);
            crear();
        }//fin constructor

        @Override
        public void actualizar(int deltaTime) {
            if (estado==ESPERANDO){
                esperar();
            }else{
                caer();
            }
        }
    public void esperar(){
        tCreacion--;
        if (tCreacion==0) {
            estado=BAJANDO;
        }
    }
    public void caer(){

        this.setY(this.getY()+STEP);

        if (this.getY()>juego.getAlto()){
            estado=ESPERANDO;
            iniciar();
        }
    }
    public void iniciar(){
        tCreacion=this.generandoTiempo();
        colocaGota();
    }

    public void colocaGota(){
        this.setY(-this.getAlto());
        this.setX((int)(Math.random()*(juego.getAncho()-this.getAncho())));
    }
    public int generandoTiempo(){
        return (int)(Math.random()*50+10);
    }

    @Override
    public void chocar(Sprite sp) {
        destruir();
    }
    public void crear(){
        setVisible(true);
        setHabilitado(true);
        estado=ESPERANDO;
        iniciar();
    }
    public void destruir(){
        setVisible(false);
        setHabilitado(false);
    }
}