/**
 * DESARROLLO DE APLICACIONES MULTIPLATAFORMA
 * MODULO: PROGRAMACION MULTIMEDIA Y DISPOSITIVOS MOVILES
 * CENTRO: COLEGIO STMA TRINIDAD
 * CURSO: 2016-2017
 **/
package com.dam.cst.juego;

import com.dam.frameWorkGame.Game;
import com.dam.frameWorkGame.SpriteTexto;

public class MainJuego extends Game {
    private Gota gota;
    private Agujero ag;
    private Agujero ag2;
    private SpriteTexto contadorGotas;
    private SpriteTexto titulo;
    protected static Game juego=Game.game;
    @Override
    public void iniciarJuego() {

        ag=new Agujero(0);
        ag2 = new Agujero(juego.getAncho()-50);
        contadorGotas=new SpriteTexto("EUREKA");
        contadorGotas.setPosicion(600,200);

        titulo=new SpriteTexto("EL METE BOLAS ");
        titulo.setPosicion(50,50);
        this.setTimeFrame(20);

    }

    @Override
    public void actualizar(long deltaTime) {
      /*  GestorDedo dedo=getGestorDedo();
        if (dedo.isTocada()){
            bola.doAccion(dedo.getTouchEvento().x,dedo.getTouchEvento().y);
        }*/

    }


}
